Run the emulation with:

  qemu-system-nios2 -kernel output/images/vmlinux -nographic

The login prompt will appear in the terminal that started Qemu.

Tested with the upcoming QEMU 2.9.0 [1]

[1] http://git.qemu.org/?p=qemu.git;h=ae5045ae5b2bbd8ce1335d1b05f9ecacca83a6cf
